<!DOCTYPE html>
<html>
<head>
    <title>PayPal Subscriptions Payment Payment Status</title>
    <meta charset="utf-8">
</head>
<body>
<div class="container">
    <h1>PayPal Subscriptions Payment Status</h1>
    <!-- render subscription details -->
    <?php echo !empty($phtml)?$phtml:''; ?>
</body>
</html>
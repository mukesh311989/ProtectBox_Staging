<style>
p{
	margin:0 0 13px;
}
</style>

 <!-- 2nd footer -->
	 <div class="container" style="background:#e6e7e9;width:100%;border-top:2px solid #ccc;height:auto;">
		  <div class="container">
			<div class="row ">
			  <div class="col-md-4 col-sm-12">
				<h3 style="border-bottom:1px solid #000;margin-bottom:10px;padding-bottom:5px;">Contact Information</h3>
				<p style="font-size:1.1em;">
					<p style="color:#010101;">Chat to us using the blue chat icon in the bottom right corner. Or email us, as shown below (or call us on +44 (0)207 993 3037), our customer service team is available Mon-Fri 9am-5pm (UK time).</p>
					<!--<i class="icon-phone-outline" aria-hidden="true" style="color:#000;"></i> <a href="tel:+442080892979" style="color:#010101;">+44 208 089 2979 (Our customer service team is available Mon-Fri 9am-9pm (UK time))</a></br>-->
					<i class="icon-mail" aria-hidden="true" style="color:#000;"></i> <a href="mailto:team@protectbox.com" style="color:#010101;">team@protectbox.com (Businesses) </a></br>
					<i class="icon-mail" aria-hidden="true" style="color:#000;"></i> <a href="mailto:supplier@protectbox.com" style="color:#010101;">supplier@protectbox.com (Suppliers)</a></br> 
					<i class="icon-mail" aria-hidden="true" style="color:#000;"></i> <a href="mailto:kiran@protectbox.com" style="color:#010101;">kiran@protectbox.com (Investors & Media) </a>
				</p>
				
				<p style="font-size:1.1em;">
					<a href="https://www.facebook.com/protectbox/" target="_BLANK" style="color:#000;background:#CCC;padding:10px;border-radius:50%;"><i class="fa icon-facebook"></i></a>
					<a href="https://www.linkedin.com/company/protectbox-ltd" target="_BLANK" style="color:#000;background:#CCC;padding:10px;border-radius:50%;"><i class="fa icon-linkedin"></i></a>
					<a href="https://twitter.com/ProtectBoxLtd/" target="_BLANK" style="color:#000;background:#CCC;padding:10px;border-radius:50%;"><i class="icon-twitter"></i></a>
					<a href="mailto:team@protectbox.com" target="_BLANK" style="color:#000;background:#CCC;padding:10px;border-radius:50%;"><i class="icon-mail"></i></a>
				
				  	  <p style="font-size:1.1em;">
					<a href="https://itunes.apple.com/us/app/apple-store/id375380948?mt=8" target="_blank">
					  <img src="<?php echo base_url();?>images/apple_store.png" style="height:30px;">
					</a>

					<a href="https://play.google.com/store?hl=en" class="" style="margin-left:10px;" target="_blank">
					  <img src="<?php echo base_url();?>images/google-play.png" style="height:30px;">
					</a>
					<br>(Coming soon)
			  </p>
				<!--<p><img src="<?php echo base_url();?>images/britain_office.png" style="border:1px solid #CCC;height:70px;"></p>-->
			  </div>
			  <div class="col-md-4 col-sm-12">
				<h3 style="border-bottom:1px solid #000;margin-bottom:10px;padding-bottom:5px;">What are you looking for</h3>
				<p style="font-size:1.1em;"><a href="<?php echo base_url('about');?>" style="color:#010101;" target="_blank">About</a></p>
				<p style="font-size:1.1em;"><a href="<?php echo base_url('register');?>" style="color:#010101;">Register</a></p>
				<p style="font-size:1.1em;"><a href="<?php echo base_url('login');?>" style="color:#010101;">Login</a></p>
				<p style="font-size:1.1em;"><a href="<?php echo base_url('contact');?>" style="color:#010101;" target="_blank">Contact Us</a></p>
			  </div>

			  <div class="col-md-4 col-sm-12" id="contact_bg">
				<h3 style="border-bottom:1px solid #000;margin-bottom:10px;padding-bottom:5px;">Useful Links</h3>
				<p style="font-size:1.1em;"><a href="<?php echo base_url('terms');?>" style="color:#010101;" target="_blank">Terms and Conditions</a></p>
				<p style="font-size:1.1em;"><a href="<?php echo base_url('privacy');?>" style="color:#010101;" target="_blank">Privacy Policy</a></p>
				<p style="font-size:1.1em;"><a href="<?php echo base_url('supplier_policy');?>" style="color:#010101;" target="_blank">Supplier Policy</a></p>
			  </div>
			</div>
			<!-- End row -->	
		  </div>

		  
	 </div>
	 	 <div class="container" style="background:#e6e7e9;width:100%;padding-bottom:20px;padding-top:20px;align:center;">
		  <div class="container">
			        <div class="row">
          <div class="col-md-1 col-sm-6 col-xs-6" style="text-align:center;">
            <div class="team_box" style="text-align:center;">
              <a href="javascript:void();"  style="text-align:center">
                <img src="<?php echo base_url();?>images/britain_office.png" class="" style="display:block;text-align:center;height:56px;padding:5px 0px 0px 0px !important;">
              </a>
         
            </div>

            </div>
            <!--<div class="col-md-2 col-sm-12" >
              <div class="team_box" style="text-align:center;">
                <a href="#" data-toggle="modal" data-target="#team_modal_roshsaran">
                  <img src="<?php echo base_url();?>images/colorado_office.png" class="" style="display:block;text-align:center;width:100%;height:76px;">
                </a>
          
            </div>

            </div>-->
            <div class="col-md-2 col-sm-6 col-xs-6" style="text-align:center;">
              <div class="team_box" style="text-align:center;">
                <a href="#" style="text-align:center;">
                  <img src="<?php echo base_url();?>images/mcafee.png" class="" style="display:block;text-align:center;height:56px;padding:5px 0px 0px 0px !important;">
                </a>
              </div>
              </div>
              <div class="col-md-2 col-sm-6 col-xs-6" style="text-align:center;">
                <div class="team_box" style="text-align:center;">
                  <a href="#" style="text-align:center;">
                    <img src="<?php echo base_url();?>images/SSLcertificate.png" class="" style="display:block;text-align:center;height:56px;padding:5px 0px 0px 0px !important;">
                  </a>
           
                </div>

                </div>
                <div class="col-md-2 col-sm-6 col-xs-6" style="text-align:center;">
                  <div class="team_box" style="text-align:center;">
                    <a href="#"  style="text-align:center;">
                      <img src="<?php echo base_url();?>images/aws1.png" class=""  style="display:block;text-align:center;height:56px;padding:5px 0px 0px 0px !important;">
                    </a>
                  
                   
                  </div>

                </div>
				<div class="col-md-2 col-sm-6 col-xs-6" style="text-align:center;">
                  <div class="team_box" style="text-align:center;">
                    <a href="#"  style="text-align:center;">
                      <img src="<?php echo base_url();?>images/pci.png" class=""  style="display:block;text-align:center;height:56px;padding:5px 0px 0px 0px !important;">
                    </a>
                  
                   
                  </div>

                </div>
                <!--<div class="col-md-2 col-sm-12">
                  <div class="team_box" style="text-align:center;">
                    <a href="#" data-toggle="modal" data-target="#team_modal_paulfinnigan2">
                      <img src="<?php echo base_url();?>images/team-6.png" class="" style="display:block;text-align:center;width:100%;height:76px;">
                    </a>
           
                  </div>

                  </div>-->
                </div>
			<!-- End row -->	
		  </div>

		  
	 </div>
	 <div id="copy" style="background:#85c62c;">
		<div class="container">
		  Copyright &copy; 2018 ProtectBox Ltd. Company number: NI643316 - VAT registration number: 297 5082 62- All rights reserved.
		</div>
	  </div>
 <!-- 2nd footer ends -->


<!--<div id="toTop"></div>-->

<!-- Common scripts -->


<!--<script src="<?php echo base_url();?>js/jquery-2.2.4.min.js"></script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.ywxi.net/js/1.js" async></script>
<script src="<?php echo base_url();?>js/common_scripts_min.js"></script>
<script src="<?php echo base_url();?>js/functions.js"></script>
<script src="<?php echo base_url();?>js/multiselect.js"></script>
<script>
	$(document).ready(function () {          
		setTimeout(function() {
			$('.mylodr').hide();
		}, 1000);
	});
	$('.tooltip-1')['tooltip']({
		html: true
	});
</script>
<!--Start of Tawk.to Script
<script type="text/javascript">
	var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
	(function(){
	var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
	s1.async=true;
	s1.src='https://embed.tawk.to/5cfa91a5b534676f32addc38/default';
	s1.charset='UTF-8';
	s1.setAttribute('crossorigin','*');
	s0.parentNode.insertBefore(s1,s0);
	})();
</script>
End of Tawk.to Script-->

<!-- Start of LiveChat (www.livechatinc.com) code -->
<!-- <script type="text/javascript">
  window.__lc = window.__lc || {};
  window.__lc.license = 10830707;
  (function() {
    var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
    lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
  })();
</script>
<noscript>
<a href="https://www.livechatinc.com/chat-with/10830707/" rel="nofollow">Chat with us</a>,
powered by <a href="https://www.livechatinc.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a>
</noscript> -->
 <!-- End of LiveChat code -->

<script>
function myFunction() {
	if($( "#mobile_menuzz" ).hasClass( "show" )){
		$("#mobile_menuzz").removeClass( "show" );
		
	}else{
		$("#mobile_menuzz").addClass( "show" );
		$("#close_in").removeClass( "open_close" );
	}
}
</script>
<!-- LayerSlider script files -->
<script type="text/javascript">
	document.onreadystatechange = function () {
	  var state = document.readyState
	  if (state == 'complete') {
		  setTimeout(function(){
			  document.getElementById('interactive');
			 document.getElementById('load').style.visibility="hidden";
		  },1000);
	  }
	}
</script>

<!-- Start of HubSpot Embed Code --> 
<script type="text/javascript" id="hs-script-loader" async defer src="//js.hs-scripts.com/5307998.js"></script>
<!-- End of HubSpot Embed Code -->